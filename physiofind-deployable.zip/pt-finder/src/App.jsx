import { useState } from "react";

// ---- Design tokens ----
const T = {
  ink: "#152420",
  pine: "#2E6B4F",
  pineDark: "#1F4A37",
  bg: "#F4F7F5",
  amber: "#B47816",
  amberBg: "#FBF3E2",
  line: "#DCE5E0",
  sub: "#5C6B64",
};
const FONT = "'Sora', system-ui, sans-serif";

const INSURANCES = [
  "Medicare",
  "Medicaid",
  "Blue Cross Blue Shield",
  "Aetna",
  "UnitedHealthcare",
  "Cigna",
  "Humana",
  "Kaiser Permanente",
];

const CALL_SCRIPT = [
  "Do you accept my insurance? (Give the exact plan name on your card.)",
  "Is there a copay per visit, and do I need prior authorization?",
  "Do you have any openings in the next 1–2 weeks?",
  "Do you need a referral or prescription faxed? What is your fax number?",
  "How long is the first evaluation visit?",
];

// Providers customize the app through URL parameters, no accounts needed:
//   ?provider=Dr.%20Smith%27s%20office   → personalizes the final message
//   ?partners=Spaulding,ATI,Bay%20State  → networks to badge as preferred
const params = new URLSearchParams(window.location.search);
const PROVIDER_NAME = params.get("provider") || "your provider's office";
const PARTNER_NETWORKS = (params.get("partners") || "")
  .split(",")
  .map((s) => s.trim())
  .filter(Boolean);

const isPreferred = (c) =>
  PARTNER_NETWORKS.some((net) => c.name.toLowerCase().includes(net.toLowerCase()));

export default function App() {
  const [step, setStep] = useState(1);
  const [zip, setZip] = useState("");
  const [insurance, setInsurance] = useState("");
  const [reason, setReason] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [clinics, setClinics] = useState([]);
  const [chosen, setChosen] = useState(null);
  const [manualName, setManualName] = useState("");
  const [apptDate, setApptDate] = useState("");
  const [faxNumber, setFaxNumber] = useState("");
  const [copied, setCopied] = useState(false);

  const preferred = clinics.filter(isPreferred);
  const others = clinics.filter((c) => !isPreferred(c));

  async function findClinics() {
    if (!/^\d{5}$/.test(zip.trim())) {
      setError("Enter a 5-digit ZIP code.");
      return;
    }
    setError("");
    setLoading(true);
    try {
      const res = await fetch(`/api/clinics?zip=${zip.trim()}`);
      const data = await res.json();
      if (!res.ok || data.error) {
        setError(data.error || "Couldn't load clinics right now. Please try again.");
        return;
      }
      if (!data.clinics || data.clinics.length === 0) {
        setError("No clinics found for that ZIP. Double-check the code and try again.");
        return;
      }
      setClinics(data.clinics);
      setStep(2);
      window.scrollTo(0, 0);
    } catch {
      setError("Couldn't load clinics right now. Please try again.");
    } finally {
      setLoading(false);
    }
  }

  function pickClinic(c) {
    setChosen(c);
    setStep(3);
    window.scrollTo(0, 0);
  }

  function pickManual() {
    if (!manualName.trim()) {
      setError("Enter the clinic name first.");
      return;
    }
    setError("");
    setChosen({ name: manualName.trim(), address: "" });
    setStep(3);
    window.scrollTo(0, 0);
  }

  function confirmationMessage() {
    return [
      `Hi — this is regarding my physical therapy referral${reason ? ` for ${reason}` : ""}.`,
      ``,
      `I scheduled my first PT appointment:`,
      `• Clinic: ${chosen?.name || "(clinic name)"}`,
      chosen?.address ? `• Address: ${chosen.address}` : null,
      chosen?.phone ? `• Clinic phone: ${chosen.phone}` : null,
      `• First visit: ${apptDate || "(date/time)"}`,
      faxNumber
        ? `• Clinic fax for the referral: ${faxNumber}`
        : `• Clinic fax: (I can get this from the clinic if needed)`,
      ``,
      `Please send the referral/prescription if the clinic needs it. Thank you!`,
    ]
      .filter((l) => l !== null)
      .join("\n");
  }

  async function copyMessage() {
    try {
      await navigator.clipboard.writeText(confirmationMessage());
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      setCopied(false);
    }
  }

  const stepLabel = ["Your info", "Find & call", "Tell your provider"];

  const clinicCard = (c) => (
    <section
      key={c.name + c.address}
      style={{ ...cardStyle, border: isPreferred(c) ? `2px solid ${T.pine}` : cardStyle.border }}
    >
      {isPreferred(c) && (
        <span style={badgeStyle}>★ Works directly with your care team</span>
      )}
      <h3 style={{ fontFamily: FONT, fontSize: 16, fontWeight: 600, margin: 0 }}>{c.name}</h3>
      <p style={{ margin: "6px 0", fontSize: 14, color: T.sub }}>{c.address}</p>
      <p style={{ margin: "0 0 10px", fontSize: 14 }}>
        {c.rating ? `${c.rating}★ (${c.ratingCount} reviews)` : ""}
        {c.rating && c.saturday ? " · " : ""}
        {c.saturday ? "Open Saturdays" : ""}
      </p>
      <div style={{ display: "flex", gap: 8 }}>
        {c.phone && (
          <a
            href={`tel:${c.phone.replace(/[^\d]/g, "")}`}
            style={{ ...primaryBtn, marginTop: 0, textDecoration: "none", textAlign: "center", flex: 1.3, display: "block" }}
          >
            Call {c.phone}
          </a>
        )}
        <button onClick={() => pickClinic(c)} style={{ ...secondaryBtn, flex: 1 }}>
          I booked here
        </button>
      </div>
    </section>
  );

  return (
    <div style={{ minHeight: "100vh", background: T.bg, fontFamily: "'Source Sans 3', system-ui, sans-serif", color: T.ink }}>
      <style>{`
        input { outline: none; }
        input:focus, button:focus-visible, a:focus-visible { box-shadow: 0 0 0 3px rgba(46,107,79,.35); }
        @media (prefers-reduced-motion: reduce) { * { transition: none !important; } }
      `}</style>

      <header style={{ background: T.pineDark, color: "#fff", padding: "20px 20px 16px" }}>
        <div style={{ maxWidth: 560, margin: "0 auto" }}>
          <h1 style={{ fontFamily: FONT, fontWeight: 700, fontSize: 22, margin: 0 }}>
            PhysioFind
          </h1>
          <p style={{ margin: "6px 0 0", fontSize: 15, opacity: 0.85 }}>
            Find physical therapy near you, confirm your insurance, and let{" "}
            {PROVIDER_NAME} know when you're booked.
          </p>
        </div>
      </header>

      <nav style={{ maxWidth: 560, margin: "0 auto", padding: "16px 20px 0", display: "flex", gap: 8 }}>
        {stepLabel.map((label, i) => {
          const n = i + 1;
          const active = step === n;
          const done = step > n;
          return (
            <div key={label} style={{ flex: 1 }}>
              <div style={{ height: 6, borderRadius: 99, background: done || active ? T.pine : T.line, transition: "background .2s" }} />
              <div style={{ marginTop: 6, fontSize: 12, fontWeight: 600, color: active ? T.pineDark : T.sub }}>
                {n}. {label}
              </div>
            </div>
          );
        })}
      </nav>

      <main style={{ maxWidth: 560, margin: "0 auto", padding: "16px 20px 40px" }}>
        {step === 1 && (
          <section style={cardStyle}>
            <h2 style={h2Style}>Let's get you set up</h2>

            <label style={labelStyle} htmlFor="zip">Your ZIP code</label>
            <input
              id="zip"
              inputMode="numeric"
              maxLength={5}
              value={zip}
              onChange={(e) => setZip(e.target.value.replace(/\D/g, ""))}
              placeholder="e.g. 02118"
              style={inputStyle}
            />

            <label style={labelStyle}>Your insurance</label>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 8, marginBottom: 8 }}>
              {INSURANCES.map((name) => (
                <button
                  key={name}
                  onClick={() => setInsurance(name)}
                  style={{
                    ...chipStyle,
                    background: insurance === name ? T.pine : "#fff",
                    color: insurance === name ? "#fff" : T.ink,
                    borderColor: insurance === name ? T.pine : T.line,
                  }}
                >
                  {name}
                </button>
              ))}
            </div>
            <input
              value={insurance}
              onChange={(e) => setInsurance(e.target.value)}
              placeholder="Or type your exact plan name"
              style={inputStyle}
            />

            <label style={labelStyle} htmlFor="reason">What is PT for? (optional)</label>
            <input
              id="reason"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="e.g. right knee, after shoulder surgery"
              style={inputStyle}
            />

            {error && <p style={errorStyle}>{error}</p>}

            <button onClick={findClinics} disabled={loading} style={{ ...primaryBtn, background: loading ? "#7FA491" : T.pine }}>
              {loading ? "Searching near you…" : "Show PT clinics near me"}
            </button>
            <p style={{ fontSize: 13, color: T.sub, margin: "10px 0 0" }}>
              Only your ZIP code is used to search. No personal information is saved.
            </p>
          </section>
        )}

        {step === 2 && (
          <>
            <section style={{ ...cardStyle, background: T.amberBg, border: "1px solid #E8D9B8" }}>
              <p style={{ margin: 0, fontSize: 14 }}>
                <strong style={{ color: T.amber }}>Always confirm by phone.</strong>{" "}
                Insurance lists online are often out of date. When you call, ask if
                they accept <strong>{insurance || "your plan"}</strong> before booking.
              </p>
            </section>

            <section style={cardStyle}>
              <h3 style={{ ...h2Style, fontSize: 16 }}>What to ask when you call</h3>
              <ol style={{ margin: 0, paddingLeft: 20, fontSize: 15, lineHeight: 1.6 }}>
                {CALL_SCRIPT.map((q) => (
                  <li key={q} style={{ marginBottom: 6 }}>{q}</li>
                ))}
              </ol>
            </section>

            {preferred.length > 0 && (
              <>
                <h2 style={{ ...h2Style, margin: "18px 0 4px" }}>Recommended clinics</h2>
                <p style={{ fontSize: 14, color: T.sub, margin: "0 0 10px" }}>
                  These clinics coordinate directly with {PROVIDER_NAME}, which makes
                  referrals and updates smoother.
                </p>
                {preferred.map(clinicCard)}
              </>
            )}

            <h2 style={{ ...h2Style, margin: "18px 0 10px" }}>
              {preferred.length > 0 ? "More clinics" : "Clinics"} near {zip}
            </h2>
            {others.map(clinicCard)}

            <section style={cardStyle}>
              <h3 style={{ ...h2Style, fontSize: 16 }}>Booked somewhere else?</h3>
              <input
                value={manualName}
                onChange={(e) => setManualName(e.target.value)}
                placeholder="Type the clinic name"
                style={inputStyle}
              />
              {error && <p style={errorStyle}>{error}</p>}
              <button onClick={pickManual} style={primaryBtn}>Use this clinic</button>
            </section>

            <button onClick={() => { setError(""); setStep(1); }} style={linkBtn}>
              ← Change my info
            </button>
          </>
        )}

        {step === 3 && chosen && (
          <>
            <section style={cardStyle}>
              <h2 style={h2Style}>Great — you booked at {chosen.name}</h2>
              <p style={{ fontSize: 15, margin: "0 0 14px" }}>
                Last step: send this message to {PROVIDER_NAME} (for example, through
                your patient portal) so they can fax your referral and mark PT as
                scheduled.
              </p>

              <label style={labelStyle} htmlFor="appt">First appointment date & time</label>
              <input
                id="appt"
                value={apptDate}
                onChange={(e) => setApptDate(e.target.value)}
                placeholder="e.g. Tue July 14, 2:30 PM"
                style={inputStyle}
              />

              <label style={labelStyle} htmlFor="fax">Clinic fax number (ask the clinic)</label>
              <input
                id="fax"
                value={faxNumber}
                onChange={(e) => setFaxNumber(e.target.value)}
                placeholder="e.g. (617) 555-0142"
                style={inputStyle}
              />

              <div style={{ background: T.bg, border: `1px solid ${T.line}`, borderRadius: 10, padding: 14, fontSize: 14, whiteSpace: "pre-wrap", marginBottom: 12 }}>
                {confirmationMessage()}
              </div>

              <button onClick={copyMessage} style={primaryBtn}>
                {copied ? "Copied ✓" : "Copy message to send"}
              </button>
              <p style={{ fontSize: 13, color: T.sub, margin: "10px 0 0" }}>
                Paste it into a portal message to {PROVIDER_NAME}.
              </p>
            </section>
            <button onClick={() => setStep(2)} style={linkBtn}>← Back to clinics</button>
          </>
        )}

        <footer style={{ marginTop: 24, fontSize: 12, color: T.sub, lineHeight: 1.5 }}>
          Clinic details come from a live search and may be incomplete — always confirm
          insurance, availability, and fax numbers directly with the clinic. This tool
          does not collect or store personal health information.
        </footer>
      </main>
    </div>
  );
}

// ---- shared styles ----
const cardStyle = { background: "#fff", border: "1px solid #DCE5E0", borderRadius: 14, padding: 18, marginBottom: 14 };
const h2Style = { fontFamily: FONT, fontSize: 18, fontWeight: 600, margin: "0 0 12px", color: T.ink };
const labelStyle = { display: "block", fontSize: 13, fontWeight: 600, color: T.sub, margin: "10px 0 6px" };
const inputStyle = { width: "100%", boxSizing: "border-box", padding: "12px 14px", fontSize: 16, border: `1px solid ${T.line}`, borderRadius: 10, background: "#fff", fontFamily: "inherit" };
const chipStyle = { padding: "8px 12px", fontSize: 14, fontWeight: 600, border: "1px solid", borderRadius: 99, cursor: "pointer", fontFamily: "inherit" };
const errorStyle = { color: "#9A3412", fontSize: 14, margin: "4px 0 8px" };
const badgeStyle = { display: "inline-block", background: T.pine, color: "#fff", fontSize: 12, fontWeight: 600, borderRadius: 99, padding: "3px 10px", marginBottom: 8 };
const primaryBtn = { width: "100%", padding: "14px 16px", fontSize: 16, fontWeight: 600, fontFamily: FONT, color: "#fff", background: T.pine, border: "none", borderRadius: 10, cursor: "pointer", marginTop: 8, boxSizing: "border-box" };
const secondaryBtn = { padding: "14px 16px", fontSize: 15, fontWeight: 600, fontFamily: FONT, color: T.pine, background: "#fff", border: `2px solid ${T.pine}`, borderRadius: 10, cursor: "pointer", boxSizing: "border-box" };
const linkBtn = { background: "none", border: "none", color: T.pine, fontSize: 15, fontWeight: 600, cursor: "pointer", padding: "8px 0", fontFamily: "inherit" };
