// Vercel serverless function: GET /api/clinics?zip=02118
// Queries Google Places API (New) Text Search. The API key stays server-side.
// No patient information is received or stored — only a ZIP code.

export default async function handler(req, res) {
  const zip = String(req.query.zip || "").trim();

  if (!/^\d{5}$/.test(zip)) {
    return res.status(400).json({ error: "Please provide a valid 5-digit ZIP code." });
  }

  const apiKey = process.env.GOOGLE_MAPS_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ error: "Server is missing the GOOGLE_MAPS_API_KEY environment variable." });
  }

  try {
    const response = await fetch("https://places.googleapis.com/v1/places:searchText", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-Goog-Api-Key": apiKey,
        "X-Goog-FieldMask":
          "places.displayName,places.formattedAddress,places.nationalPhoneNumber,places.regularOpeningHours.weekdayDescriptions,places.rating,places.userRatingCount",
      },
      body: JSON.stringify({
        textQuery: `outpatient physical therapy clinic near ${zip}`,
        maxResultCount: 12,
      }),
    });

    if (!response.ok) {
      const detail = await response.text();
      console.error("Places API error:", response.status, detail);
      return res.status(502).json({ error: "Clinic lookup failed. Please try again." });
    }

    const data = await response.json();
    const clinics = (data.places || []).map((p) => ({
      name: p.displayName?.text || "",
      address: p.formattedAddress || "",
      phone: p.nationalPhoneNumber || "",
      rating: p.rating || null,
      ratingCount: p.userRatingCount || null,
      saturday: (p.regularOpeningHours?.weekdayDescriptions || []).some(
        (d) => d.startsWith("Saturday") && !d.includes("Closed")
      ),
    })).filter((c) => c.name && c.address);

    // Cache identical ZIP lookups at the edge for a day to conserve API quota
    res.setHeader("Cache-Control", "s-maxage=86400, stale-while-revalidate");
    return res.status(200).json({ clinics });
  } catch (err) {
    console.error("Clinic lookup error:", err);
    return res.status(500).json({ error: "Clinic lookup failed. Please try again." });
  }
}
